from typing import Union
import sys
import subprocess
from fastapi import FastAPI

app = FastAPI()
def run_program():
    s2_out = s2_out = subprocess.check_output([sys.executable, "certmailer.py"])
    return s2_out

@app.get("/")
async def read_root():
    return run_program()
"""
@app.get("/")
def read_root():
    return {"Hello": "Mohammed"}


@app.get("/items/{item_id}")
def read_item(item_id: int, q: Union[str, None] = None):
    return {"item_id": item_id, "q": q}
"""